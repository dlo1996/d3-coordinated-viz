(function(){
var attArray= ["varA", "varB", "varC", "varD", "varE"];
var expressed = attArray[0];

//begin script when window loads
window.onload = setMap();
function setMap(){

    //map frame dimensions
  var width = window.innerWidth * 0.5,
    height = 460;

    //create new svg container for the map
  var map = d3.select("body")
    .append("svg")
    .attr("class", "map")
    .attr("width", width)
    .attr("height", height);

    //create Albers equal area conic projection centered on France
  var projection = d3.geoAlbers()
    .center([39.8283, 98.5795])
    .rotate([-2, 0, 0])
    .parallels([-149, -78])
    .scale(2500)
    .translate([width / 2, height / 2]);

  var path = d3.geoPath()
    .projection(projection);

    //use Promise.all to parallelize asynchronous data loading
    var promises = [];
    promises.push(d3.csv("data/PovertyReport.csv")); //load attributes from csv
    promises.push(d3.json("data/USA.topojson")); //load  spatial data
    Promise.all(promises).then(callback);

    function callback(data){
      csvData = data[0];
      unitedStates = data[1];
      console.log(csvData);
      console.log(unitedStates);

      var unitedStates = topojson.feature(unitedStates, unitedStates.objects.qgisUSA)

        var attArray= ["varA", "varB", "varC", "varD", "varE"];
        for (var i=0; i<csvData.length; i++){
          var csvPoverty = csvData[i];
          var csvKey = csvPoverty.state_National;

          for var a=0; a< unitedStates.length; a++){

            var geojsonProps = unitedStates[a].properties
            var geojsonKey = geojsonProps.state_National;

            if (geojsonKey==csvKey){
              attArray.forEach(function(attr){
                var val = parseFloat(csvPoverty[attr]);
                geojsonProps[attr] = val;
            });
          };
        };
      };
      var colorScale = makeColorScale(csvData);
      setEnumerationUnits(unitedStates, map, path, colorScale)
      setChart(csvData, colorScale);

      var unitedStatesProvinces = map.selectAll(".unitedStates")
      .data(USA)
      .enter()
      .append("path")
      .attr("class", function(d){
        return "unitedStates " + d.properties.state_National;
      unitedStates = joinData(unitedStates, map, path);
    });
      .attr("d", path)
      .style("fill", function(d){
        return colorScale(d.properties[expressed]);
      });

    };


};
function setChart(csvData, colorScale){
  var chartWidth = window.innerWidth * 0.425,
    chartHeight = 460,
    leftPadding = 25,
    rightPadding = 2,
    topBottomPadding = 5,
    chartInnerWidth = chartWidth - leftPadding - rightPadding,
    chartInnerHeight = chartHeight - topBottomPadding * 2,
    translate = "translate(" + leftPadding + "," + topBottomPadding + ")"
  var chart = d3.select("body")
    .append("svg")
    .attr("width", chartWidth)
    .attr("height",chartHeight)
    .attr("class", "chart")
  var chartBackground = chart.append("rect")
    .attr("class", "chartBackground")
    .attr("width", chartInnerWidth)
    .attr("height", chartInnerHeight)
    .attr("transform", translate);

  var chartTitle = chart.append("text")
    .attr("x", 20)
    .attr("y", 40)
    .attr("class", "chartTitle")
    .text("Rate of poverty " + expressed[3] + " in each state");

  var yScale = d3.scaleLinear()
    .range([0, chartHeight])
    .domain([0, 105]);

  var bars = chart.selectAll(".bars")
    .data(csvData)
    .enter()
    .append("rect")
    .sort(function(a, b){
      return a[expressed]-b[expressed]
    })
    .attr("class", function(d){
      return "bar " + d.state_National;
    })
    .attr("width", chartInnerWidth / csvData.length - 1)
    .attr("x", function(d, i){
      return i * (chartInnerWidth / csvData.length) + leftPadding;
    })
    .attr("height", function(d, i){
      return 463 - yScale(parseFloat(d[expressed]));
    })
    .attr("y", function(d, i){
      return yScale(parseFloat(d[expressed])) + topBottomPadding;
    })
    .style("fill", function(d){
      return choropleth(d, colorScale);
    });
  var numbers = chart.selectAll(".numbers")
      .data(csvData)
      .enter()
      .append("text")
      .sort(function(a, b){
          return a[expressed]-b[expressed]
      })
      .attr("class", function(d){
          return "numbers " + d.state_National;
      })
      .attr("text-anchor", "middle")
      .attr("x", function(d, i){
          var fraction = chartWidth / csvData.length;
          return i * fraction + (fraction - 1) / 2;
      })
      .attr("y", function(d){
          return chartHeight - yScale(parseFloat(d[expressed])) + 15;
      })
      .text(function(d){
          return d[expressed];
    });
    .attr("width", chartWidth / csvData.length - 1)
    .attr("x", function(d,i){
      return i *(chartWidth/ csvData.length);
  })
    .attr("height", function(d){
      return yScale(parseFloat(d[expressed]));
    })
    .attr("y", function(d){
      return chartHeight - yScale(parseFloat(d[expressed]));
    });
    //create vertical axis generator
  var yAxis = d3.axisLeft()
    .scale(yScale);

    //place axis
  var axis = chart.append("g")
    .attr("class", "axis")
    .attr("transform", translate)
    .call(yAxis);

    //create frame for chart border
  var chartFrame = chart.append("rect")
    .attr("class", "chartFrame")
    .attr("width", chartInnerWidth)
    .attr("height", chartInnerHeight)
    .attr("transform", translate);
};
  var graticule = d3.geoGraticule()
    .step([5, 5]);
    var gratBackground = map.append("path")
    .datum(graticule.outline())
    .attr("class", "gratBackground")
    .attr("d", path)
    var gratLines = map.selectAll(".gratLines")
    .data(graticule.lines())
    .enter()
    .append("path")
    .attr("class", "gratLines")
    .attr("d", path);

  function makeColorScale(data){
    var colorClass =[
      "#D4B9DA",
      "#C994C7",
      "#DF65B0",
      "#DD1C77",
      "#980043"
    ];
    //create color scale generator
    var colorScale = d3.scaleThreshold()
        .range(colorClasses);

    //build array of all values of the expressed attribute
    var domainArray = [];
    for (var i=0; i<data.length; i++){
        var val = parseFloat(data[i][expressed]);
        domainArray.push(val);
    };

    //cluster data using ckmeans clustering algorithm to create natural breaks
    var clusters = ss.ckmeans(domainArray, 5);
    //reset domain array to cluster minimums
    domainArray = clusters.map(function(d){
        return d3.min(d);
    });
    //remove first value from domain array to create class breakpoints
    domainArray.shift();

    //assign array of last 4 cluster minimums as domain
    colorScale.domain(domainArray);

    return colorScale;
};
})();
