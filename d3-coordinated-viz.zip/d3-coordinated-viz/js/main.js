(function(){
var attArray= ["2010", "2012", "2013", "2014", "2015"];
var expressed = attArray[0];
//chart set up
var chartWidth = window.innerWidth * 0.425,
  chartHeight = 473,
  leftPadding = 25,
  rightPadding = 2,
  topBottomPadding = 5,
  chartInnerWidth = chartWidth - leftPadding - rightPadding,
  chartInnerHeight = chartHeight - topBottomPadding * 2,
  translate = "translate(" + leftPadding + "," + topBottomPadding + ")";
//scale for frame and axis
var yScale = d3.scaleLinear()
  .range([463, 0])
  .domain([0, 30]);

window.onload = setMap();

function setMap(){
  var width = window.innerWidth * 0.5,
  height = 460;
//svg for map
var map = d3.select("body")
  .append("svg")
  .attr("class", "map")
  .attr("width", width)
  .attr("height", height);
//albers equal conic for the united states
var projection = d3.geoAlbers()
   .center([10, 37.0])
   // .rotate([-2, 0])
   // .parallels([31, 62])
   .scale(900)
   //.translate([width/ 2, height/ 2]);

var path = d3.geoPath()
  .projection(projection);

var promises = [];
promises.push(d3.csv("data/povertyReport.csv"));
promises.push(d3.json("data/usa_shapefile.topojson"));
Promise.all(promises).then(callback);
//create data
function callback(data){
  csvPoverty = data[0];
  usa = data[1];

  setGraticule(map, path);
// putting the USA data into topojson
  var usaCountries = topojson.feature(usa, usa.objects.usa_shapefile).features;
  console.log(usaCountries);

  var countries = map.append("append")
    .datum(usaCountries)
    .attr("class", "countries")
    .attr("d", path);
//data join
  usaCountries = joinData(usaCountries, csvPoverty);

  var colorScale = makeColorScale(csvPoverty);

  setEnumerationUnits(usaCountries, map, path, colorScale);

  setChart(csvPoverty, colorScale);

  createDropdown(csvPoverty);
  };
};
// graticules set up
function setGraticule(map, path){
  var graticule = d3.geoGraticule()
    .step([5, 5]);
//background graticule
  var gratBackground = map.append("path")
    .datum(graticule.outline())
    .attr("class", "gratBackground")
    .attr("d", path)
//graticule lines
  var gratLines = map.selectAll(".gratLines")
    .data(graticule.lines())
    .enter()
    .append("path")
    .attr("class", "gratLines")
    .attr("d", path);
};
//data join assigning data
function joinData(usaCountries, csvPoverty){
  for(var i=0; i<csvPoverty.lenght; i++){
    var csvState = csvPoverty[i];
    var csvKey = csvState.adm1_code;

    for (var a=0; a<usaCountries.length; a++){
      var geojsonProps = usaCountries[a].properties;
      var geojsonKey = geojsonProps.adm1_code;

      if (geojsonKey == csvKey){
        attArray.forEach(function(attr){
          var val = parseFloat(csvState[attr]);
          geojsonProps[attr] = val;
        });
      };
    };
  };
  return usaCountries;
};

function setEnumerationUnits(usaCountries, map, path, colorScale){
// adding states to the map
  var states = map.selectAll(".states")
    .data(usaCountries)
    .enter()
    .append("path")
    .attr("class", function(d){
      return "states " + d.properties.adm1_code;
    })
    .attr("d", path)
    .style("fill", function(d){
      return choropleth(d.properties, colorScale);
    })
    .on("mouseover", function(d){
      highlight(d.properties);
    })
    .on("mouseout", function(d){
      dehighlight(d.properties);
    })
  var desc = states.append("desc")
    .text('{"stroke": "#000", "stroke-width": "0.6px"}');
};
//assigning colors
function makeColorScale(data){
  var colorClasses = [
    "#FF7F50",
    "#B22222",
    "#DF65B0",
    "#A0522D",
    "#C994C7"
  ];
//color scale
  var colorScale = d3.scaleThreshold()
    .range(colorClasses);

  var domainArray =[];
  for (var i=0; i<data.length; i++){
      var val = parseFloat(data[i][expressed]);
      domainArray.push(val);
  };
//clustering data
  var clusters = ss.ckmeans(domainArray, 5);

  domainArray = clusters.map(function(d){
    return d3.min(d);
  });
  domainArray.shift();
  colorScale.domain(domainArray);
  return colorScale;
};
//looks at data and gives color
function choropleth(props, colorScale){

	var val = parseFloat(props[expressed]);

	if (val && val != NaN){
		  return colorScale(val);
	} else {
		  return "#CCC";
	};
};
//creating bar graph
function setChart(csvPoverty, colorScale){
  var chart = d3.select("body")
    .append("svg")
    .attr("width", chartWidth)
    .attr("height", chartHeight)
    .attr("class", "chart");

  var chartBackground = chart.append("rect")
		.attr("class", "chartBackground")
		.attr("width", chartInnerWidth)
		.attr("height", chartInnerHeight)
		.attr("transform", translate);

  var bars = chart.selectAll(".bar")
    .data(csvPoverty)
    .enter()
    .append("rect")
    .sort(function(a, b){
			return b[expressed]-a[expressed]
		})
		.attr("class", function(d){
			return "bar " + d.adm1_code;
		})
    .attr("width", chartInnerWidth / csvPoverty.length -1)
    .on("mouseover", highlight)
    .on("mouseout", dehighlight)
    .on("mouseover", moveLabel);

  var desc = bars.append("desc")
    .text('{"stroke": none, "stroke-width": "0px"}');

  var chartTitle = chart.append("text")
    .attr("x", 40)
    .attr("y", 40)
    .attr("class", "chartTitle");

  var yAxis = d3.axisLeft(yScale);

  var axis = chart.append("g")
    .attr("class", "axis")
    .attr("transform", translate)
    .call(yAxis);

  var chartFrame = chart.append("rect")
    .attr("class", "chartFrame")
    .attr("width", chartInnerWidth)
    .attr("height", chartInnerHeight)
    .attr("transform", translate);

  updateChart(bars, csvPoverty.length, colorScale);
};
//creating background menu
function createDropdown(csvPoverty){

  var dropdown = d3.select("body")
    .append("select")
    .attr("class", "dropdown")
    .on("change", function(){
      changeAttribute(this.value, csvPoverty)
    });

  var titleOption = dropdown.append("option")
    .attr("class", "titleOption")
    .attr("disabled", "true")
    .text("Select Attribute");

  var attrOptions = dropdown.selectAll("attrOptions")
    .data(attArray)
    .enter()
    .append("option")
    .attr("value", function(d){ return d })
    .text(function(d){ return d });
};

function changeAttribute(attribute, csvPoverty){
  expressed = attribute;

  var colorScale = makeColorScale(csvPoverty);

  var states = d3.selectAll(".states")
    .transition()
    .duration(1000)
    .style("fill", function(d){
      return choropleth(d.properties, colorScale)
    });

  var bars = d3.selectAll(".bar")
    .sort(function(a, b){
      return b[expressed] - a[expressed];
    })
    .transition()
    .delay(function(d, i){
      return i * 20
    })
    .duration(500);
  updateChart(bars, csvPoverty.length, colorScale);
};
//creating data inside the bar graph
function updateChart(bars, n, colorScale){
  bars.attr("x", function(d, i){
      return i * (chartInnerWidth / n) + leftPadding;
    })
    .attr("height", function(d, i){
      return 463 - yScale(parseFloat(d[expressed]));
    })
    .attr("y", function(d, i){
      return yScale(parseFloat(d[expressed])) + topBottomPadding;
    })
    .style("fill", function(d){
      return choropleth(d, colorScale)
    });
  var chartTitle = d3.select(".chartTitle")
    .text("Rate of Poverty in " + expressed);
};

function highlight(props){
  var selected = d3.selectAll("." +props.adm1_code)
    .styles({
      "stroke": "blue",
      "stroke-width": "3"
    });
  setLabel(props);
};
//creating a dynamic label
function setLabel(props){
  var labelAttribute = "<h1>" + props[expressed] + "</h1><b>" + expressed + "</b>";

  var infolabel = d3.select("body")
    .append("div")
    .attrs({
      "class": "infolabel",
      "id": props.adm1_code + "_label"
    })
    .html(labelAttribute);

  var stateName = infolabel.append("div")
    .attr("class", "labelname")
    .html(props.name);
};
//dehighlight when mouse moves away
function dehighlight(props){
  var selected = d3.selectAll("." + props.adm1_code)
    .styles({
      "stroke": function(){
        return getStyle(this, "stroke")
      },
      "stoke-width": function(){
        return getStyle(this, "stroke-width")
      }
    });

  function getStyle(element, styleName){
    var styleText = d3.select(element)
      .select("desc")
      .text();
    var styleObject = JSON.parse(styleText);
    return styleObject[styleName];
  };
  d3.select(".infolabel")
    .remove();
};
//moving label with the mouse
function moveLabel(){
  var labelWidth = d3.select(".infolabel")
    .node()
    .getBoundingClientRect()
    // .width();

  var x1 = d3.event.clientX + 10,
      y1 = d3.event.clientY - 75,
      x2 = d3.event.clientX - labelWidth - 10,
      y2 = d3.event.clientY +25;

  var x = d3.event.clientX > window.innerWidth - labelWidth - 2 ? x2 : x1;

  var y = d3.event.clientY < 75 ? y2 : y1;

  d3.select("infolabel")
    .styles({
      "left": x + "px",
      "top": y + "px"
    });
};

})();
